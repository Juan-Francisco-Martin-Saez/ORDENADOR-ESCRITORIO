import './squares.js';

