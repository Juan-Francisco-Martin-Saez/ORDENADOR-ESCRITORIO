import './faqs.js';

